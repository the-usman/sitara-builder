import { motion } from 'framer-motion';
import ArrowAnimation from './ArrowAnimation';
import LogoPlaceholder from './LogoPlaceholder';
import EmailCTA from './EmailCTA';
import CharacterSign from './CharacterSign';

const launchingSoonSrc = "https://res.cloudinary.com/lafaaku5/image/upload/v1789459337/gigzos401yg0oi7dytw0.png";
const stayTunedSrc = "https://res.cloudinary.com/lafaaku5/image/upload/v1789459305/rweye52dxvqory7asvg9.png";

export default function ComingSoonPage() {
  return (
    <main
      className="relative w-full min-h-screen overflow-hidden"
      style={{
        backgroundColor: '#0E0B20',
        fontFamily: "'Jost', sans-serif",
      }}
    >
      {/* Bottom purple atmospheric glow (blurred solid shapes) */}
      <div
        aria-hidden="true"
        className="absolute left-1/2 -translate-x-1/2 pointer-events-none"
        style={{
          bottom: '-25%',
          width: '140%',
          height: '70%',
          backgroundColor: '#AD00FF',
          filter: 'blur(120px)',
          opacity: 0.55,
          borderRadius: '50%',
        }}
      />
      <div
        aria-hidden="true"
        className="absolute left-1/2 -translate-x-1/2 pointer-events-none"
        style={{
          bottom: '-15%',
          width: '90%',
          height: '45%',
          backgroundColor: '#AD00FF',
          filter: 'blur(80px)',
          opacity: 0.4,
          borderRadius: '50%',
        }}
      />

      {/* Top-left animated arrows */}
      <ArrowAnimation />

      {/* Central content container */}
      <div className="relative z-20 flex flex-col items-center justify-center min-h-screen px-4 sm:px-6 pt-24 sm:pt-16 md:pt-20 pb-64 sm:pb-72 md:pb-80">
        <div className="w-full max-w-3xl mx-auto flex flex-col items-center text-center gap-5 sm:gap-6 md:gap-7">
          {/* Logo */}
          <LogoPlaceholder />

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className="text-white font-extrabold leading-[1.1] text-3xl sm:text-4xl md:text-5xl lg:text-[3.25rem]"
            style={{ fontFamily: "'Jost', sans-serif" }}
          >
            <span className="block sm:inline">Branding and</span>
            <br className="hidden sm:block" />
            <span className="block sm:inline"> Communication Agency</span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.45, ease: [0.22, 1, 0.36, 1] }}
            className="text-white font-normal text-base sm:text-lg md:text-xl lg:text-2xl -mt-2"
            style={{ fontFamily: "'Jost', sans-serif" }}
          >
            with AI Tools Integration
          </motion.p>

          {/* Email CTA */}
          <div className="mt-3 sm:mt-4">
            <EmailCTA />
          </div>
        </div>
      </div>

      {/* Left character - Launching Soon (image replacement) */}
      <CharacterSign
        side="left"
        imageSrc={launchingSoonSrc}
        imageId="LaunchingSoon"
      />

      {/* Right character - Stay Tuned (image replacement) */}
      <CharacterSign
        side="right"
        imageSrc={stayTunedSrc}
        imageId="StayTuned"
      />
    </main>
  );
}
