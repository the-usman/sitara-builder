import { motion } from 'framer-motion';

const logoSrc = "https://res.cloudinary.com/lafaaku5/image/upload/v1789460364/o7ddlcnbbllumezh15dr.png";

export default function LogoPlaceholder() {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col items-center justify-center"
    >
      <img
        id="D2Mlogo"
        alt="D2 Media Communication"
        src={logoSrc}
        className="w-[140px] sm:w-[170px] md:w-[200px] lg:w-[220px] h-auto object-contain"
        draggable={false}
      />
    </motion.div>
  );
}
