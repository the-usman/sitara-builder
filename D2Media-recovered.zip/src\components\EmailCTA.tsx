import { motion } from 'framer-motion';

export default function EmailCTA() {
  return (
    <motion.a
      href="mailto:hello@d2media.com.au"
      aria-label="Email hello@d2media.com.au"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.98 }}
      className="inline-flex items-center justify-center gap-3 px-8 sm:px-10 py-4 sm:py-5 rounded-full text-white font-medium text-base sm:text-lg md:text-xl transition-all duration-200 hover:brightness-110 focus:outline-none focus-visible:ring-4 focus-visible:ring-white/30 cursor-pointer"
      style={{
        backgroundColor: '#FF0063',
        fontFamily: "'Jost', sans-serif",
      }}
    >
      <svg
        width="26"
        height="26"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
        aria-hidden="true"
      >
        <path
          d="M3 6.5C3 5.67 3.67 5 4.5 5h15c.83 0 1.5.67 1.5 1.5v11c0 .83-.67 1.5-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5v-11Z"
          fill="#FFFF00"
        />
        <path
          d="m4 7 8 6 8-6"
          stroke="#0E0B20"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      <span className="whitespace-nowrap">hello@d2media.com.au</span>
    </motion.a>
  );
}
