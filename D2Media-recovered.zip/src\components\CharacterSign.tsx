import { motion } from 'framer-motion';

interface CharacterSignProps {
  side: 'left' | 'right';
  imageSrc: string;
  imageId: 'LaunchingSoon' | 'StayTuned';
}

export default function CharacterSign({ side, imageSrc, imageId }: CharacterSignProps) {
  const isLeft = side === 'left';

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 0.8, ease: [0.22, 1, 0.36, 1] }}
      className={`absolute bottom-0 ${
        isLeft ? 'left-0 sm:left-2 md:left-6 lg:left-12' : 'right-0 sm:right-2 md:right-6 lg:right-12'
      } z-10 pointer-events-none select-none flex flex-col items-center`}
      aria-hidden="true"
    >
      <motion.div
        animate={{ y: [0, -4, 0] }}
        transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
        className="relative flex flex-col items-center"
      >
        <img
          id={imageId}
          src={imageSrc}
          alt=""
          className="w-[150px] sm:w-[190px] md:w-[240px] lg:w-[280px] h-auto object-contain"
          draggable={false}
        />
      </motion.div>
    </motion.div>
  );
}
