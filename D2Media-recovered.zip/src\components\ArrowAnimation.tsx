import { motion } from 'framer-motion';

const Chevron = ({ color, size = 80 }: { color: string; size?: number }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 100 100"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <path
      d="M25 15 L70 50 L25 85"
      stroke={color}
      strokeWidth="16"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
  </svg>
);

export default function ArrowAnimation() {
  return (
    <div
      className="absolute top-6 left-6 sm:top-10 sm:left-10 md:top-12 md:left-16 z-10 pointer-events-none select-none"
      aria-hidden="true"
    >
      <div className="relative w-[130px] h-[160px] sm:w-[170px] sm:h-[200px] md:w-[210px] md:h-[240px]">
        {/* Top pink chevron - large */}
        <motion.div
          className="absolute top-0 left-6"
          animate={{
            x: [0, 8, 0],
            y: [0, -4, 0],
            rotate: [0, 3, 0],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          <Chevron color="#FF0063" size={90} />
        </motion.div>

        {/* Bottom yellow chevron - small */}
        <motion.div
          className="absolute bottom-0 left-0"
          animate={{
            x: [0, -6, 0],
            y: [0, 4, 0],
            rotate: [0, -4, 0],
          }}
          transition={{
            duration: 3.5,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: 0.3,
          }}
        >
          <Chevron color="#FFFF00" size={45} />
        </motion.div>

        {/* Bottom purple chevron - medium */}
        <motion.div
          className="absolute bottom-2 left-14"
          animate={{
            x: [0, 6, 0],
            y: [0, 5, 0],
            rotate: [0, 4, 0],
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 4.5,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: 0.6,
          }}
        >
          <Chevron color="#AD00FF" size={65} />
        </motion.div>
      </div>
    </div>
  );
}
